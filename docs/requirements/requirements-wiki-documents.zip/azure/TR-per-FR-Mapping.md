# TR per FR Mapping (MCP Server)

| FR | Primary TRs | Tests |
| --- | --- | --- |
| FR-VALHALLA-002 | TR-VALHALLA-BUILD-002 | TEST-VALHALLA-002 |
| FR-VALHALLA-003 | TR-VALHALLA-TEST-003 | TEST-VALHALLA-003 |
